from Food import Food
from turtle import *
from Snake import Snake
from Scoreboard import Score
import time

screen = Screen()
screen.setup(width=1440, height=900)
screen.bgcolor("black")
screen.title("Snake")
screen.tracer(0)

snake = Snake()
food = Food()
score = Score()

screen.listen()
screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")

game_over = False
food_eaten = False
while not game_over:
    screen.update()
    snake.move()
    time.sleep(0.01)
    if snake.head.distance(food) < 50:
        food.refresh()
        snake.extend()
        score.score_increase()

    if snake.head.xcor() > 715 or snake.head.xcor() < -715 or snake.head.ycor() > 445 or snake.head.ycor() < -445:
        game_over = True
        score.game_over()

    for snakes in snake.snakes[1:]:
        if snake.head.distance(snakes) < 10:
            game_over = False
            score.game_over()



screen.exitonclick()





