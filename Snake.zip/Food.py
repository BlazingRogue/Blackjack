from turtle import *
import random

SCORE = 0

class Food(Turtle):

    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.shape("turtle")
        self.penup()
        self.shapesize(stretch_len=2, stretch_wid=2)
        self.color("Green")
        self.speed(0)
        self.refresh()

    def refresh(self):
        random_x = random.randint(-700, 700)
        random_y = random.randint(-400, 400)
        self.goto(random_x, random_y)
        self.showturtle()
