from turtle import *

UP = 90
DOWN = 270
STARTING_POSITIONS = [(-350, 0), (350, 0)]


class Paddles:

    def __init__(self):
        self.paddle = []
        self.create_paddle()
        self.head = self.paddle[0]
        self.computer = self.paddle[1]

    def create_paddle(self):
        for positions in STARTING_POSITIONS:
            self.add_paddle(positions)

    def add_paddle(self, positions):
        new_paddle = Turtle("square")
        new_paddle.shapesize(5, 1, 1)
        new_paddle.color("White")
        new_paddle.penup()
        new_paddle.goto(positions)
        self.paddle.append(new_paddle)

    def up(self):
        new_y = self.head.ycor() + 50
        self.paddle[0].goto(self.paddle[0].xcor(), new_y)

    def down(self):
        new_y = self.head.ycor() - 50
        self.paddle[0].goto(self.paddle[0].xcor(), new_y)

    def up2(self):
        new_y = self.computer.ycor() + 50
        self.paddle[1].goto(self.paddle[1].xcor(), new_y)

    def down2(self):
        new_y = self.computer.ycor() - 50
        self.paddle[1].goto(self.paddle[1].xcor(), new_y)
