from turtle import *

STARTING_POSITIONS = [-100, 200]


class Score(Turtle):

    def __init__(self):
        super().__init__()
        self.color("white")
        self.penup()
        self.hideturtle()
        self.r_score = 0
        self.l_score = 0

    def update_scoreboard(self):
        self.clear()
        self.goto(-100, 200)
        self.write(f"{self.r_score}", False, align="center", font=('Courier', 80, 'normal'))
        self.goto(100, 200)
        self.write(f"{self.l_score}", False, align="center", font=('Courier', 80, 'normal'))

    def r_point(self):
        self.r_score += 1
        self.update_scoreboard()

    def l_point(self):
        self.l_score += 1
        self.update_scoreboard()
