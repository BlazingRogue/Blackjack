
from turtle import *
STARTING_POSITIONS = [(0, 0)]


class Ball:

    def __init__(self):
        self.ball = []
        self.create_ball()
        self.real = self.ball[0]
        self.x_move = 10
        self.y_move = 10

    def create_ball(self):
        for positions in STARTING_POSITIONS:
            self.add_ball(positions)

    def add_ball(self, positions):
        new_ball = Turtle("circle")
        new_ball.shapesize(1, 1, 1)
        new_ball.color("White")
        new_ball.penup()
        new_ball.goto(positions)
        self.ball.append(new_ball)

    def move(self):
        new_x = self.real.xcor() + self.x_move
        new_y = self.real.ycor() + self.y_move
        self.real.goto(new_x, new_y)

    def bounce(self):
        self.y_move *= -1

    def bounce_x(self):
        self.x_move *= -1

    def reset_position(self):
        self.real.goto(0, 0)
        self.bounce_x()

