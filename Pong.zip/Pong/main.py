from Ball import Ball
from turtle import *
from Paddles import Paddles
from Score import Score
import time

screen = Screen()
screen.setup(width=800, height=600)
screen.bgcolor("black")
screen.title("Pong")
screen.tracer(0)

paddle = Paddles()
score = Score()
screen.tracer(1)
ball = Ball()

screen.listen()

screen.onkey(paddle.up, "Up")
screen.onkey(paddle.down, "Down")
screen.onkey(paddle.up2, "Left")
screen.onkey(paddle.down2, "Right")

game_over = False
while not game_over:

    screen.update()
    ball.move()

    if ball.real.ycor() > 300 or ball.real.ycor() < -300:
        ball.bounce()

    if ball.real.distance(paddle.head) < 50 and ball.real.xcor() < -320 or ball.real.distance(paddle.computer) < 50 and ball.real.xcor() > 320:
        ball.bounce_x()
        ball.x_move += 2

    if ball.real.xcor() > 400:
        ball.reset_position()
        score.l_point()

    if ball.real.xcor() < -400:
        ball.reset_position()
        score.r_point()

screen.exitonclick()
