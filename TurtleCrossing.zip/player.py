from turtle import *
import random

UP = 90
DOWN = 270
STARTING_POSITIONS = [(0, -380), (-100, -380,), (100, -380)]


class Player:

    def __init__(self):
        self.player = []
        self.add_player()
        self.head = self.player[0]
        self.head.setheading(90)

    # def create_player(self):
    #     for positions in STARTING_POSITIONS:
    #         self.add_player(positions)

    def add_player(self):
        new_player = Turtle("turtle")
        new_player.shapesize(1, 1, 1)
        new_player.color("black")
        new_player.penup()
        new_player.goto(random.choice(STARTING_POSITIONS))
        self.player.append(new_player)

    def up(self):
        new_y = self.head.ycor() + 30
        self.player[0].goto(self.player[0].xcor(), new_y)

    def down(self):
        new_y = self.head.ycor() - 30
        self.player[0].goto(self.player[0].xcor(), new_y)

    def reset(self):
        self.head.goto(random.choice(STARTING_POSITIONS))

