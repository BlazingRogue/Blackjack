import random
from turtle import *
from player import Player

STARTING_POSITIONS = [(0, 0)]
COLORS = ["red", "orange", "yellow", "blue", "green", "purple"]
difficulty = input("What difficulty? 'easy', or 'impossible'").lower()
player = Player()

class CarManager:

    def __init__(self):
        self.car = []
        self.create_car()
        self.x_move = -10

    def create_car(self):
        if difficulty == 'impossible':
            for positions in range(5):
                self.add_car(positions)
        else:
            for positions in range(1):
                self.add_car(positions)

    def add_car(self, positions):
        new_car = Turtle("square")
        new_car.shapesize(1, random.randint(1, 2), 1)
        new_car.color(random.choice(COLORS))
        new_car.penup()
        new_car.goto(400, random.randint(-300, 300))
        self.car.append(new_car)

    def remove(self):
        for cars in range(len(self.car)):
            try:
                if self.car[cars].xcor() < -400:
                    self.car.remove(cars)
                    self.car[cars].clear()
            except ValueError:
                continue
            else:
                continue

    def move(self):
        for cars in range(len(self.car) - 1):
            new_x = self.car[cars].xcor() + self.x_move
            self.car[cars].goto(new_x, self.car[cars].ycor())

    def reset(self):
        self.x_move += -2



        # for cars in range(len(self.car)-1):
        #     if self.car[cars].distance(player.head) < 200:
        #         return True
        #     else:
        #         return False
