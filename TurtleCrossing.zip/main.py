import time
from turtle import *
from player import Player
from car_manager import CarManager
from score import Score

screen = Screen()
screen.setup(width=800, height=800)

screen.title("Crossing")
screen.tracer(0)

player = Player()
car = CarManager()
score = Score()


def quit():
    screen.exitonclick()


screen.listen()
screen.onkey(player.up, "Up")
screen.onkey(player.down, "Down")

game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()

    car.create_car()
    car.remove()
    car.move()

    for i, cars in enumerate(car.car):
        if car.car[i].distance(player.head) < 10:
            print("You lost")
            game_is_on = False

    if player.head.ycor() > 350:
        player.reset()
        car.reset()
        score.level_up()

    if score.level > 100:
        screen.exitonclick()


